# Final artifact import

The original completed consistency_v1 artifacts and executed notebook were imported from the user-provided Downloads folder. Completed candidate checkpoints, histories, selection records, metrics, manifests, splits, comparison files, plots, and the BRACS local-feature launcher are included. Interrupted backup folders and superseded manifest backups were excluded from the submission package; originals remain unchanged in Downloads. Spreadsheet copies of histories are retained as auxiliary files.

Excluded backup paths:
- `.DS_Store`
- `BRACS/experiment_manifest_backup_20261026_174244_927635.json`
- `BRACS/experiment_manifest_backup_20261026_051059_279893.json`
- `C17/.DS_Store`
- `BRACS/incomplete_20261026_174244_927635_sigma_0.05_lambda_0.1/history.csv`
- `BRACS/incomplete_20261026_174244_927635_sigma_0.05_lambda_0.1/best_model.pt`
- `BRACS/incomplete_20261026_182939_686288_sigma_0.05_lambda_0.1/history.csv`
- `BRACS/incomplete_20261026_182939_686288_sigma_0.05_lambda_0.1/best_model.pt`
- `BRACS/incomplete_20261026_050837_200342_sigma_0.01_lambda_1/history.csv`
- `BRACS/incomplete_20261026_050837_200342_sigma_0.01_lambda_1/best_model.pt`
