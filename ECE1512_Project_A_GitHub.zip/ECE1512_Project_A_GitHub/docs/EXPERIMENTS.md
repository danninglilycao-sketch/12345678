# Experimental settings

Baseline and extension use the saved splits, 384-dimensional pre-extracted features, an inner dimension of 256, gated attention dimension 128, batch size 1, AdamW lr=0.0001, weight decay=0.00001, seed=42, and 30 epochs per configuration. Class counts: C16=2, C17=4, BRACS=7. The config contains `warmup_epoch`, but the historical runner does not implement a warmup scheduler; do not describe warmup as used.

The extension objective averages clean/noisy cross-entropy and adds lambda times symmetric KL. Noise is iid Gaussian at valid feature positions only. Grid: sigma={0.01,0.05}, lambda={0.1,1}. Checkpoint and candidate selection maximizes validation macro-AUROC+macro-F1. No test-based tuning is performed by the runner. Accuracy is in percent, AUC/F1 in [0,1].

Selected configurations reported by the saved output shown in Colab:

| Dataset | sigma | lambda | epoch |
|---|---:|---:|---:|
| C16 | 0.01 | 0.1 | 3 |
| C17 | 0.01 | 1.0 | 21 |
| BRACS | 0.05 | 0.1 | 7 |

All performance tables/plots in this repository must be generated from original JSON/CSV artifacts, not filled in from screenshots. Missing cloud artifacts are a packaging gap, not a reason to fabricate replacement logs. File/split checks are not independent retraining.
