# Packaging validation

The original synthetic implementation checks passed locally on Python 3.12 / PyTorch 2.8 (CPU): masked noise, zero noise, symmetric KL, both-branch gradients, padding invariance, parameter updates and small synthetic C16/C17/BRACS pipelines. This is not real-data retraining.

Final C16, C17 and BRACS artifacts all passed `tools/check_results.py`: matching baseline/extension splits, no duplicate or overlapping slide IDs, required baseline and extension files, four completed 30-epoch histories per dataset, correct validation-selected epochs and candidates, and finite test metrics. All three extension manifests match the SHA-256 of the original research_extension.py. No checkpoint pickle was deserialized for these checks.

`tools/report_results.py` regenerated the final comparison CSV and PNG/PDF metric and selected-loss figures from original saved results. The executed notebook was imported with recorded outputs. No full real-data independent training reproduction was performed.
