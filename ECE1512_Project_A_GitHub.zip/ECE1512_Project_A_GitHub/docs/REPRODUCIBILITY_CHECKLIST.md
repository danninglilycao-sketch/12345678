# Reproducibility checklists

These are two separate checklists for the report and code artifacts. Confirm report items against the final exported group PDF; code checks can be rerun without training.

## Report artifact

- [ ] Include the actual GitHub repository URL and reviewer access instructions.
- [ ] Include two proposals, with only Proposal 2 presented as implemented.
- [ ] Define the mask, Gaussian noise, shared model, CE, and symmetric KL objective.
- [ ] Describe the saved splits, feature representation, seed, optimizer, and epoch count.
- [ ] Disclose the four-configuration search budget and validation-only selection criterion.
- [ ] Include final test tables, metric comparison, selected configuration losses, and captions.
- [ ] Discuss mixed/negative results, overfitting, and small KL magnitudes carefully.
- [ ] State single-seed and missing-ablation limitations; avoid robustness/novelty claims.
- [ ] Verify citations, IEEE-like formatting, equations, and the group report page limit.

## Code artifact

- [x] Original model, extension, loader, metrics helpers, configs, and baseline splits packaged locally.
- [x] Data download and run instructions provided in README.
- [x] Original extension source is retained rather than silently modified.
- [ ] Latest executed cloud notebook imported.
- [ ] Original cloud C16/C17/BRACS extension JSON, CSV, and checkpoints imported.
- [ ] Run `python tools/check_results.py --project .` on the final package.
- [ ] Run `python tools/report_results.py --project .` and inspect generated plots.
- [x] Synthetic checks completed on the final package (see VALIDATION.md).
- [ ] Verify remote GitHub tree includes required artifacts and excludes raw HDF5/features.
- [ ] An independent full real-data training reproduction was performed. (Not required for the recorded file checks; leave unchecked if not performed.)
