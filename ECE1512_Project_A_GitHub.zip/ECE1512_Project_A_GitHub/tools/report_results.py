"""Regenerate comparison and selected loss figures from original saved JSON/CSV."""
import argparse, json
from pathlib import Path
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def report(project,run):
    root=project/'results_extension'/run
    summaries={ds:json.loads((root/ds/'metrics.json').read_text()) for ds in ['C16','C17','BRACS']}
    rows=[]
    for ds,summary in summaries.items():
        baseline=json.loads((project/'results'/ds/'metrics.json').read_text())['test_metrics']
        for metric in ['acc','auc','f1','loss']:
            new=summary['test_metrics'][metric]
            rows.append(dict(Dataset=ds,Metric=metric,Baseline=baseline[metric],Extension=new,Delta=new-baseline[metric]))
    comparison=pd.DataFrame(rows)
    comparison.to_csv(root/'final_test_comparison.csv',index=False)
    out=root/'report_figures';out.mkdir(exist_ok=True)
    fig,axes=plt.subplots(1,3,figsize=(14,4))
    for ax,metric,title in zip(axes,['acc','auc','f1'],['Accuracy (%)','Macro-AUROC','Macro-F1']):
        subset=comparison[comparison.Metric==metric].set_index('Dataset').loc[list(summaries)]
        for i,(method,color) in enumerate(zip(['Baseline','Extension'],['#4677B4','#E59A38'])):
            bars=ax.bar([j+(i-.5)*.36 for j in range(3)],subset[method],width=.36,label=method,color=color)
            ax.bar_label(bars,fmt='%.2f' if metric=='acc' else '%.4f',fontsize=8)
        ax.set_xticks(range(3),list(summaries));ax.set_title(title)
        ax.set_ylim(0,105 if metric=='acc' else 1.05);ax.grid(axis='y',alpha=.2);ax.set_axisbelow(True)
    fig.legend(*axes[0].get_legend_handles_labels(),loc='lower center',ncol=2)
    fig.tight_layout(rect=[0,.12,1,1])
    for suffix in ['png','pdf']:fig.savefig(out/f'metric_comparison.{suffix}',dpi=300)
    plt.close(fig)
    for ds,summary in summaries.items():
        name=summary['selected_candidate'];history=pd.read_csv(root/ds/name/'history.csv')
        fig,axes=plt.subplots(1,2,figsize=(11,4))
        axes[0].plot(history.epoch,history.train_ce_loss,label='Training CE (clean + perturbed)')
        axes[0].plot(history.epoch,history.val_loss,label='Validation CE (clean)')
        axes[0].axvline(summary['best_epoch'],color='gray',ls='--',label=f"Selected epoch: {summary['best_epoch']}")
        axes[0].set(xlabel='Epoch',ylabel='Cross-entropy',title=f'{ds}: classification loss')
        axes[1].plot(history.epoch,history.train_consistency_loss,color='#6A9F58',label='Training symmetric KL')
        axes[1].set(xlabel='Epoch',ylabel='Consistency loss',title=f'{ds}: consistency regularization')
        for ax in axes:ax.grid(alpha=.2);ax.legend(fontsize=8)
        fig.suptitle(f'{ds}: {name}');fig.tight_layout()
        for suffix in ['png','pdf']:fig.savefig(out/f'{ds}_selected_losses.{suffix}',dpi=300)
        plt.close(fig)
    print(comparison.round(4).to_string(index=False));print('Figures saved to:',out)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--project',type=Path,default=Path(__file__).resolve().parents[1]);ap.add_argument('--run',default='consistency_v1')
    args=ap.parse_args();report(args.project,args.run)
