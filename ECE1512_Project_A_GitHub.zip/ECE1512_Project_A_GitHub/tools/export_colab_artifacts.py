from pathlib import Path
import zipfile
from google.colab import drive, files

drive.mount("/content/drive")
PROJECT = Path("/content/drive/MyDrive/Project_A_ABMIL_Completed")
assert PROJECT.is_dir(), "Project folder not found."
archive = Path("/content/Project_A_Final_Artifacts.zip")
allowed = {".py", ".ipynb", ".json", ".csv", ".yml", ".yaml", ".md", ".txt", ".png", ".pdf", ".svg", ".pt", ".pth", ".log"}
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as z:
    for path in PROJECT.rglob("*"):
        if not path.is_file():
            continue
        rel = path.relative_to(PROJECT)
        if any(part in {"feature", "slide", "__pycache__", ".git", ".ipynb_checkpoints", "consistency_v2"} or part.startswith("incomplete_") for part in rel.parts):
            continue
        if path.name.startswith("experiment_manifest_backup_"):
            continue
        if path.suffix.lower() in allowed:
            z.write(path, rel)
print("Exported completed project files:", archive)
files.download(str(archive))
