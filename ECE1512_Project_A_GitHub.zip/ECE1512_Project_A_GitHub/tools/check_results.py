"""Read-only checks of archived results; no training or checkpoint deserialization."""
import argparse, csv, json, math
from pathlib import Path


def load(path):
    return json.loads(path.read_text())


def check(project, run):
    failures = []
    for ds in ['C16', 'C17', 'BRACS']:
        try:
            baseline = project / 'results' / ds
            extension = project / 'results_extension' / run / ds
            bsplit, esplit = load(baseline/'splits.json'), load(extension/'splits.json')
            assert bsplit == esplit, 'Baseline and extension split records differ'
            for record in [bsplit, esplit]:
                groups = [record[k] for k in ['train', 'val', 'test']]
                assert all(len(x)==len(set(x)) for x in groups), 'Duplicate slide IDs'
                assert all(not set(groups[i]) & set(groups[j]) for i,j in [(0,1),(0,2),(1,2)]), 'Overlapping slide splits'
            for name in ['history.csv', 'best_model.pt', 'metrics.json']:
                assert (baseline/name).is_file(), f'Missing baseline {name}'
            summary = load(extension/'metrics.json')
            candidate = summary['selected_candidate']
            assert Path(candidate).name == candidate, 'Unsafe candidate name'
            scores=[]
            for sigma in [0.01,0.05]:
                for weight in [0.1,1.0]:
                    name=f'sigma_{sigma:g}_lambda_{weight:g}'
                    folder=extension/name
                    assert (folder/'best_model.pt').is_file(), f'Missing checkpoint: {name}'
                    selection=load(folder/'selection.json')
                    with (folder/'history.csv').open() as f:
                        rows=list(csv.DictReader(f))
                    assert [int(r['epoch']) for r in rows]==list(range(1,31)), f'Incomplete history: {name}'
                    best=max(rows,key=lambda r:float(r['val_auc'])+float(r['val_f1']))
                    score=float(best['val_auc'])+float(best['val_f1'])
                    assert int(best['epoch'])==selection['best_epoch'], f'Wrong selected epoch: {name}'
                    assert math.isclose(score,selection['validation_score'],abs_tol=1e-7), f'Wrong validation score: {name}'
                    scores.append((selection['validation_score'],name))
            assert max(scores,key=lambda x:x[0])[1]==candidate, 'Wrong selected candidate'
            assert summary['best_epoch']==load(extension/candidate/'selection.json')['best_epoch'], 'Epoch mismatch'
            for obj in [load(baseline/'metrics.json'),summary]:
                assert all(math.isfinite(obj['test_metrics'][k]) for k in ['acc','auc','f1','loss']), 'Invalid test metrics'
            print(f'{ds}: saved files, selection records, and slide split checks passed.')
        except (OSError,ValueError,KeyError,AssertionError) as error:
            failures.append(f'{ds}: {error}')
    for failure in failures:
        print('FAIL:',failure)
    return not failures

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('--project',type=Path,default=Path(__file__).resolve().parents[1])
    ap.add_argument('--run',default='consistency_v1')
    args=ap.parse_args()
    raise SystemExit(0 if check(args.project,args.run) else 1)
