
import os
import sys
from pathlib import Path

project, local_file, run_name = sys.argv[1:4]
sys.path.insert(0, project)
os.chdir(project)

import research_extension as extension

OriginalDataset = extension.HDF5FeatureDataset

class LocalFeatureDataset(OriginalDataset):
    def __init__(self, file_path, slide_names, conf):
        if str(conf.dataset).upper() == "BRACS":
            file_path = local_file
        super().__init__(file_path, slide_names, conf)

extension.HDF5FeatureDataset = LocalFeatureDataset

print("Reading BRACS features from:", local_file, flush=True)

sys.argv = [
    str(Path(project) / "research_extension.py"),
    "--project", project,
    "--run", run_name,
    "--datasets", "BRACS",
    "--sigmas", "0.01", "0.05",
    "--weights", "0.1", "1.0",
]

extension.main()
