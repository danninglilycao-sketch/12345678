# Experiment comparison

Accuracy is in percent; accuracy deltas are percentage points. Other deltas use raw metric units.
Single-seed comparisons do not establish statistical significance.

| Dataset | Metric | Baseline | Extension | Delta |
|---|---|---:|---:|---:|
| C16 | acc | 82.9457 | 88.3721 | +5.4264 |
| C16 | auc | 0.8704 | 0.9227 | +0.0523 |
| C16 | f1 | 0.8159 | 0.8714 | +0.0554 |
| C16 | loss | 0.4165 | 0.2700 | -0.1465 |
| C17 | acc | 79.0000 | 80.5000 | +1.5000 |
| C17 | auc | 0.8351 | 0.8260 | -0.0091 |
| C17 | f1 | 0.5258 | 0.5759 | +0.0501 |
| C17 | loss | 0.7032 | 0.7532 | +0.0500 |
| BRACS | acc | 47.6744 | 45.3488 | -2.3256 |
| BRACS | auc | 0.8155 | 0.8155 | +0.0000 |
| BRACS | f1 | 0.4077 | 0.3668 | -0.0409 |
| BRACS | loss | 1.3560 | 1.3731 | +0.0171 |

Interpret improvements/decreases after execution. Potential mechanisms (hypotheses, not established causes): regularization may reduce sensitivity; excessive noise may remove sparse diagnostic signals; class imbalance and dataset differences may affect macro-F1. No causal or generalization claim follows from an unrun experiment.